﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using LitwareLib;


namespace Assignment2
{
    public class Program
    {
        public delegate void info();
       
        static void Main(string[] args)
        {
            //EMPLOYEE DETAILS
            Employee obj1 = new Employee();

            Console.WriteLine("Enter Employee Number:");
            int no = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Employee Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Employee Salary:");
            double Salary = double.Parse(Console.ReadLine());

            obj1.setEmpDetails(no, name, Salary);
            obj1.getEmpDetails();

            Console.WriteLine("HRA: {0}",obj1.SetHRA());
            Console.WriteLine("TA: {0}",obj1.SetTA());
            Console.WriteLine("DA: {0}",obj1.SetDA());

           
            double gross1 = obj1.SetGrossSalary();
            Console.WriteLine("Gross Salary is: {0}", obj1.SetGrossSalary());
            obj1.CalculateSalary(gross1);


            ////--------SERIALIATION--------
            //FileStream f = new FileStream(@"D:\Ritu\FileIO\EmployeeDetails.txt", FileMode.Open, FileAccess.Write);
            //BinaryFormatter b = new BinaryFormatter();
            //b.Serialize(f, obj1);
            //f.Close();

            ////------deserialization------ -

            //FileStream fr = new FileStream(@"D:\Ritu\FileIO\EmployeeDetails.txt", FileMode.Open, FileAccess.Read);
            //BinaryFormatter br = new BinaryFormatter();
            //br.Deserialize(fr);

            //MANAGER DETAILS
            Console.WriteLine("\n----------Manager Details----------");
            Manager obj2 = new Manager();
            Console.WriteLine("Petrol Allowance is: {0}", obj2.setPetrol(Salary));
            Console.WriteLine("Food Allowance is: {0}", obj2.setFood(Salary));
            Console.WriteLine("Other Allowances are: {0}", obj2.setOther(Salary));

            double gross2 = obj2.Gross_Salary();
            double Manager_gross = gross1 + gross2;
            Console.WriteLine("Gross Salary of Manager after adding allowances is: {0}", Manager_gross);
            obj2.CalculateSalary(Manager_gross);
            //obj2.showSalary();

            //USING UNICAST DELEGATE TO SHOW DETAILS OF MANAGER
            info infodele = new info(obj2.showSalary);
            infodele.Invoke();
            


            //MARKETING EXECUTIVE DETAILS
            Console.WriteLine("\n----------Marketing Executive Details----------");
            MarketingExecutive obj3 = new MarketingExecutive();
            Console.WriteLine("Traveled for: {0}km", obj3.getKilometer());
            Console.WriteLine("Tour Allowance is: {0}", obj3.Tour_Allowance());
            Console.WriteLine("Telephone Allowance is: {0}", obj3.Telephone_Allowance());

            double gross3 = obj3.gross_salary();
            double Marketing_gross = Manager_gross + gross3;
            Console.WriteLine("Gross Salary of Marketing Executive after adding allowances is: {0}", Marketing_gross);
            obj3.CalculateSalary(Marketing_gross);
            //obj3.DisplaySalary();

            //USING MULTICAST DELEGATE TO SHOW DETAILS OF MARKETING EXECUTIVE
            infodele +=obj3.DisplaySalary;


            //SEARCHING A EMPLOYEE
            //create a list
            List<string> list = new List<string>();
            //add elements in the list
            list.Add(name);//here name is string which used to enter the employeename in the main method 

            Console.WriteLine("\nEnter the employee name to search");
            string target = Console.ReadLine();

            bool isexist = list.Contains(target);
            if (isexist)
            {
                Console.WriteLine("Element found in the list");
            }
            else
            {
                Console.WriteLine("Element not found in the given list");
            }


        }


    }
}