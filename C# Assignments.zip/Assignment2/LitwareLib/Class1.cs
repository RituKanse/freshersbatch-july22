﻿using System;

namespace LitwareLib
{
    [Serializable]
    public class Employee
    {
        int EmpNo;
        string EmpName;
        double Salary;
        double HRA;
        double TA;
        double DA;
        double PF;
        double TDS;
        double NetSalary;
        double GrossSalary;

        public int _EmpNo
        {
            get
            {
                return EmpNo;
            }

            set
            {
                EmpNo = value;
            }
        }

        public string _EmpName
        {
            get
            {
                return EmpName;
            }

            set
            {
                EmpName = value;
            }
        }


        public double _Salary
        {
            get
            {
                return Salary;
            }

            set
            {
                Salary = value;
            }
        }

        public double _PF
        {
            get
            {
                return PF;
            }
            set
            {
                PF = value;
            }
        }

        public double _TDS
        {
            get
            {
                return TDS;
            }
            set
            {
                TDS = value;
            }
        }

        public double _GrossSalary
        {
            get
            {
                return GrossSalary;
            }

            set
            {
                GrossSalary = value;
            }
        }

        public double _NetSalary
        {
            get
            {
                return NetSalary;
            }

            set
            {
                NetSalary = value;
            }
        }

        public void setEmpDetails(int EmpNo, string EmpName, double Salary)
        {
            this.EmpNo = EmpNo;
            this.EmpName = EmpName;
            this.Salary = Salary;

            //Console.WriteLine("Enter the Employee Number: ");
            //EmpNo = int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter the Employee Name: ");
            //EmpName = Console.ReadLine();
            //Console.WriteLine("Enter the Salary: ");
            //Salary = double.Parse(Console.ReadLine());


        } 

        public void getEmpDetails()
        {
            Console.WriteLine("\n-----------Employee Details-----------");
            Console.WriteLine("Employee Number: " + EmpNo);
            Console.WriteLine("Employee Name: " + EmpName);
            Console.WriteLine("Employee Salary: " + Salary);
        }

        public double SetHRA()
        {
            if(Salary < 5000)
            {
                HRA = (10 * Salary) / 100;
                return HRA;
            }
            else if (Salary>5000 & Salary < 10000)
            {
                HRA = (15 * Salary) / 100;
                return HRA;
            }
            else if (Salary>10000 & Salary < 15000)
            {
                HRA = (20 * Salary) / 100;
                return HRA;
            }
            else if (Salary>15000 & Salary < 20000)
            {
                HRA = (25 * Salary) / 100;
                return HRA;
            }
            else 
            {
                HRA = (30 * Salary) / 100;
                return HRA;
            }
        }

        public double SetTA()
        {
            if (Salary < 5000)
            {
                TA = (5 * Salary) / 100;
                return TA;
            }
            else if (Salary>5000 & Salary < 10000)
            {
                TA = (10 * Salary) / 100;
                return TA;
            }
            else if (Salary>10000 & Salary < 15000)
            {
                TA = (15 * Salary) / 100;
                return TA;
            }
            else if (Salary>15000 & Salary < 20000)
            {
                TA = (20 * Salary) / 100;
                return TA;
            }
            else
            {
                TA = (25 * Salary) / 100;
                return TA;
            }
        }

        public double SetDA()
        {
            if (Salary < 5000)
            {
                DA = (15 * Salary) / 100;
                return DA;
            }
            else if (Salary>5000 & Salary < 10000 )
            {
                DA = (20 * Salary) / 100;
                return DA;
            }
            else if (Salary>10000 & Salary < 15000)
            {
                DA = (25 * Salary) / 100;
                return DA;
            }
            else if (Salary>15000 & Salary < 20000)
            {
                DA = (30 * Salary) / 100;
                return DA;
            }
            else
            {
                DA = (35 * Salary) / 100;
                return DA;
            }
        }

        public double SetGrossSalary()
        {
            
                GrossSalary = Salary + HRA + TA + DA;
                return GrossSalary;  
        }

        public virtual void CalculateSalary(double GrossSalary)
        {
            PF = (10 * GrossSalary) / 100;
            TDS= (18 * GrossSalary) / 100;
            NetSalary = GrossSalary - (PF + TDS);
            Console.WriteLine("PF is: {0}",PF);
            Console.WriteLine("TDS is: {0}",TDS);
            Console.WriteLine("NetSalary is: {0}", NetSalary);

        }
    }

    //MANAGER
    public class Manager : Employee
        {
            private double Petrol, Food, Other;

            public double setPetrol(double _Salary)
            {
                Petrol = (8 * _Salary) / 100;
                return Petrol;    
            }

            public double setFood(double _Salary)
            {
                Food = (13 * _Salary) / 100;
                return Food;
                
            }

            public double setOther(double _Salary)
            {
                Other = (3 * _Salary) / 100;
                return Other;
            }

            public double Gross_Salary()
            {
                _GrossSalary = Petrol + Food + Other;
                return _GrossSalary;

            }

            public override void CalculateSalary(double _GrossSalary)
            {
                _PF = (10 * _GrossSalary ) / 100;
                _TDS = (18 * _GrossSalary) / 100;
                _NetSalary = _GrossSalary - (_PF + _TDS);
            }
            public void showSalary()
            {
                Console.WriteLine("Your PF is: {0}", _PF);
                Console.WriteLine("Your TDS is: {0}", _TDS);
                Console.WriteLine("Your NetSalary is: {0}", _NetSalary);
            }
        }


        //MARKETING EXECUTIVE
        public class MarketingExecutive : Manager
        {
            private double KilometerTravel;
            private double Tour, Telephone;

            public double getKilometer()
            {
                Console.WriteLine("Enter the kilometers Traveled: ");
                KilometerTravel = double.Parse(Console.ReadLine());
                return KilometerTravel;

            }

            public double Tour_Allowance()
            {
                Tour = 5 * KilometerTravel;
                return Tour;
            }

            public double Telephone_Allowance()
            {
                Telephone = 1000;
                return Telephone;
            }

            public double gross_salary()
            {
                _GrossSalary = Tour + Telephone;
                return _GrossSalary;
            }

            public override void CalculateSalary(double GrossSalary)
            {
                
                _PF = (10 * GrossSalary) / 100;
                _TDS = (18 * GrossSalary) / 100;
                _NetSalary = GrossSalary - (_PF + _TDS);

            }
            public void DisplaySalary()
            {
                Console.WriteLine("Your PF is: {0}", _PF);
                Console.WriteLine("Your TDS is: {0}",_TDS);
                Console.WriteLine("Your NetSalary is: {0}",_NetSalary);
            }
        }


    
}
