﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class LinkedList
    {
        class Employee
        {
            public int EmpID { get; set; }
            public string EmpName { get; set; }
            public int EmpSalary { get; set; }
        }

        static void Main(string[] args)
        {
            Employee employee1 = new Employee()
            {
                EmpID = 1,
                EmpName = "Arya",
                EmpSalary = 50000
            };

            List<Employee> employees = new List<Employee>(1);
            employees.Add(employee1);

            Console.WriteLine("List of Employees");
            foreach (Employee c in employees)
            {
                Console.WriteLine("ID={0}, Name={1}, Salary={2}", c.EmpID, c.EmpName, c.EmpSalary);
            }
        again:
            Console.WriteLine("\nDo you want to add emoployee---yes or no");
            string choice = Console.ReadLine();

            if (choice.ToLower() == "yes")
            {
                Employee employeen = new Employee();
                Console.WriteLine("\nEnter your employee id");
                employeen.EmpID = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter employee name");
                employeen.EmpName = Console.ReadLine();
                Console.WriteLine("Enter employee salary");
                employeen.EmpSalary = int.Parse(Console.ReadLine());

                employees.Add(employeen);
                goto again;
            }
            else
            {
                Console.WriteLine(" ");
            }
            Console.WriteLine("Total no.of employees =" + employees.Count);

            Console.WriteLine("\nList of Employees");
            foreach (Employee c in employees)
            {
                
                Console.WriteLine("ID={0} \t Name={1} \t Salary={2}", c.EmpID, c.EmpName, c.EmpSalary);
            }
        }
    }

}

