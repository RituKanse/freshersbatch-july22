﻿using System;
using System.Collections;
using LitwareLib;

namespace Assignment5_Oues2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            Employee emp2 = new Employee();
            Employee emp3 = new Employee();

            emp1.setEmpDetails(101, "Ritu", 20000);
            emp2.setEmpDetails(102, "Asavari", 15000);
            emp3.setEmpDetails(103, "Shama", 12000);

            ArrayList empList = new ArrayList();
            empList.Add(emp1);
            empList.Add(emp2);
            empList.Add(emp3);
            Console.WriteLine("Displaying Employee Details from Employee Array List: ");

            foreach (Employee employee in empList)
            {
                Console.WriteLine($"ID: {employee._EmpNo} \t Name: {employee._EmpName} \t Salary: {employee._Salary}");
            }
            Console.ReadLine();
        }
    }
    
}
