﻿
namespace Assignment7
{
    class BankAccount
    {
        public delegate void dele();

        public double AccountNumber;
        public string Name;
        public double bankbalance;
        public void data()
        {
            Console.WriteLine("Enter account number");
            AccountNumber = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter name");
            Name = Console.ReadLine();
            Console.WriteLine("Bank balance");
            bankbalance = int.Parse(Console.ReadLine());
            Console.WriteLine("\nAccount number={0}\nname={1}\nbank balance={2}", AccountNumber, Name, bankbalance);
            string filepath = @"D:\Ritu\FileIO\Bank_Details.txt";
            StreamWriter sw = File.CreateText(filepath);
            sw.WriteLine("\naccount number=" + AccountNumber);
            sw.WriteLine("name=" + Name);
            sw.WriteLine("bankbalance=" + bankbalance);
            sw.Close();

            Console.WriteLine("\n---data reading---");
            using (StreamReader sr = File.OpenText(filepath))

            {
                String s = "";

                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }



        }

        class AccountInfo
        {
            public static void Main()
            {
                try
                {
                    BankAccount b = new BankAccount();
                    

                    dele obj = new dele(b.data);
                    obj.Invoke();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                }
            }
        }
    }
}
