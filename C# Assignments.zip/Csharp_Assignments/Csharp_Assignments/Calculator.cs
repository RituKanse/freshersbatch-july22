﻿namespace Csharp_Assignments
{
    class Calculator
    {
        public static void Addition(int a,int b)
        {
            int result = a + b;
            Console.WriteLine("Addition Result is: {0}",result);
        }

        public static void Subtraction(int a, int b)
        {
            int result = a - b;
            Console.WriteLine("Subtraction Result is: {0}", result);
        }

        public static void Multiplication(int a, int b)
        {
            int result = a * b;
            Console.WriteLine("Multiplication Result is: {0}", result);
        }

        public static void Division(int a, int b)
        {
            int result = a / b;
            Console.WriteLine("Division Result is: {0}", result);
        }
        static void Main(string[] args)
        {
            start:
            
            try
            {
                Console.WriteLine("Enter First Number:");
                int num1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Second Number:");
                int num2 = int.Parse(Console.ReadLine());
            
                Console.WriteLine("Choose your operator +,-,*,/");
                string op = Console.ReadLine();

                switch(op)
                {
                    case "+":
                        Calculator.Addition(num1,num2);
                        break;
                    case "-":
                        Calculator.Subtraction(num1, num2);
                        break;
                    case "*":
                        Calculator.Multiplication(num1, num2);
                        break;
                    case "/":
                        Calculator.Division(num1, num2);
                        break;
                
                    default:
                        Console.WriteLine( "Invalid Input");
                        break;
                }


                Console.WriteLine("\n-----Do you want to continue(y/n):-----");
                string decide = Console.ReadLine();
                switch (decide.ToLower())
                {
                    case "y":
                        goto start;
                    case "n":
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        goto start;
                   
                }
                     }
                catch
                {
                    Console.WriteLine("Invalid input");
                }
        }
    }
}