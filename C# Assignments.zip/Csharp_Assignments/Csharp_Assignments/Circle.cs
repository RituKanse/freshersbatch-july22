﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assignments
{
    class Circle
    {
        public void Calculate()
        {
            const double PI=3.17;
            double r, Area, Circum;
            Console.WriteLine("Enter the Radius of Circle:");
            r=double.Parse(Console.ReadLine());
            Area = PI * r * r;
            Circum = 2 * PI * r;
            Console.WriteLine("Area of Circle is:"+Area);
            Console.WriteLine("Circumference of Circle is:"+Circum);
        }

        static void Main(string[] args)
        {
            Circle c = new Circle();
            c.Calculate();
        }
    }
}
