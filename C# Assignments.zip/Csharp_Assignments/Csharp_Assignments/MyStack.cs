﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assignments
{
    class MyStack
    {
        private int[] StackArray;
        private int top;   //index of top of the stack
        private int max;
        public MyStack(int size)
        {
            StackArray = new int[size];
            top = -1;   //empty stack
            max = size;  // size = 3 max = 3
        }

        public void push(int item)
        {
            if (top == max - 1)    // max - 1 = index of the top  
            {
                throw new StackException("Stack OverFlow !! You are trying to add items to the Stack that is full.");
            }
            else
            {
                StackArray[++top] = item;  //increment index
            }
        }

        public int pop()
        {
            if (top == -1)
            {
                throw new StackException("Error: No element to pop");
            }
            else
            {
                Console.WriteLine("Popped element is: " + StackArray[top]);
                return StackArray[top--];   // decrement the index
            }
        }
        public void displayStack()
        {
            if (top == -1)
            {
                throw new StackException("Stack is Empty");
            }
            else
            {
                Console.WriteLine("Items inserted are: ");
                for (int i = 0; i <= top; i++)
                {
                    Console.WriteLine("Item[" + (i + 1) + "]: " + StackArray[i]);
                }
            }
        }

    }


    class Program
    {
        static void Main()
        {
            MyStack S = new MyStack(5);

            try
            {
                S.push(133);
                S.push(213);
                S.push(768);
                S.push(140);
                S.push(15);
                S.push(10);
            }
            catch (StackException se)
            {
                Console.WriteLine(se);
            }


            try
            {
                S.pop();
                S.pop();

            }
            catch (StackException se)
            {
                Console.WriteLine(se);
            }

            try
            {
                S.displayStack();
            }
            catch (StackException se)
            {
                Console.WriteLine(se);
            }

            Console.ReadLine();
        }
    }

    public class StackException : Exception
    {
        public StackException(string s) : base(s)
        {

        }
    }

}
