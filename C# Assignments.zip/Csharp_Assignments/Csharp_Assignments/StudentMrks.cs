﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assignments
{
    class StudentMrks
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Marks of five students:");
            int[] marks = new int[5];
            int avg = 0;
            int sum = 0;
            for (int i = 0; i < marks.Length; i++)
            {
                int mrk = int.Parse(Console.ReadLine());
                marks[i] = mrk;
                sum += marks[i];
                avg = sum / marks.Length;
            }
            Console.WriteLine("Average marks of five students: {0}", avg);
            int highest = marks.Max();
            Console.WriteLine("Highest marks obtained are:"+highest);
        }
    }
}
