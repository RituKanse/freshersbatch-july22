﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assignments
{
    class SumOfIntegers
    {
        public static void Sum()
        {
            Console.WriteLine("Enter the number of elements you want:");
            int num = int.Parse(Console.ReadLine());
            
            int[] arr = new int[num];
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter the {0} elements:", i+1);
                int ele = int.Parse(Console.ReadLine());
                arr[i] = ele;
                sum += arr[i];
                
            }
            Console.WriteLine("Sum of Integers is:"+sum);
        }

        static void Main(string[] args)
        {
            SumOfIntegers.Sum();
        }
    }
}
