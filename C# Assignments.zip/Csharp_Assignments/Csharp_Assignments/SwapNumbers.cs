﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_Assignments
{
    class SwapNumbers
    {
        public static void Sum()
        {
            int num;
            Console.WriteLine("Enter the First number");
            int a=int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Second number");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("The two numbers are:");
            Console.WriteLine("a={0}, b={1}",a,b);


            num = a;
            a = b;
            b = num;
            


            Console.WriteLine("\nNumbers after swapping are:");
            Console.WriteLine("a={0}, b={1}", a,b);

            
        }

            static void Main(string[] args)
            {
                SwapNumbers.Sum();
            
            }
    }
}
